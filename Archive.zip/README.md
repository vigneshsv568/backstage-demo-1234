# springboot-kotlin-service

This repository contains a standard springboot kotlin service. 

To learn more about this project, read the [technical documentation](docs/index.md).

