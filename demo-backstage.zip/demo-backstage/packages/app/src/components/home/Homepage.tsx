import React from 'react';

export const HomePage = () => {
  /* We will shortly compose a pretty homepage here. */
  return <h1>Welcome to Backstage!</h1>;
};