export { helloPlugin, HelloPage } from './plugin';
